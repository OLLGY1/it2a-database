﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace it2a___databaze
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ZakladniHry();
            DataContext = this;
            dgVideohry.ItemsSource = ListHer;
        }
        public ObservableCollection<Hry> ListHer = new()
        {

        };
        //public void Button_Click(object sender, RoutedEventArgs e)
        //{
        //Hry hra = new Hry()
        //{
        //Id = IdTextBox.Text,
        //  Jmeno = JmenoTextBox.Text,
        //  Autor = AutorTextBox.Text,
        //       Rok = RokTextBox.Text,
        //       Typ = TypTextBox.Text,
        //       PocetKusu = PocetKusuTextBox.Text,
        //        JeDostupna = JeDostupnaCheckBox.IsChecked ?? false
        //    };
        //    ListHer.Add(hra);
        //    HryListView.ItemsSource = ListHer;
        // }

        public void ZakladniHry()
        {
            ListHer.Add(new Hry { Jmeno = "Peglin", Autor = "IndieArk", Rok = "2024", Typ = "Pachinko Roguelike", PocetKusu = "143", JeDostupna = true });
            ListHer.Add(new Hry { Jmeno = "Outcore", Autor = "Doctor Shinobi", Rok = "2022", Typ = "Desktop Adventure", PocetKusu = "Morbillion", JeDostupna = true });
            ListHer.Add(new Hry { Jmeno = "Ena: Dream BBQ", Autor = "Joel G", Rok = "2025", Typ = "Surrealism", PocetKusu = "52", JeDostupna = true });
        }
        public void Button_Click(object sender, RoutedEventArgs e)
        {
            Hry hra = new Hry()
            {
                Jmeno = JmenoTextBox.Text,
                Autor = AutorTextBox.Text,
                Rok = RokTextBox.Text,
                Typ = TypTextBox.Text,
                PocetKusu = PocetKusuTextBox.Text,
                JeDostupna = JeDostupnaCheckBox.IsChecked ?? false
            };
            ListHer.Add(hra);
            dgVideohry.ItemsSource = ListHer;
        }
    }
}