﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace it2a___databaze
{ 

    public class Hry
    {
        public int Id;
        public string Jmeno { get; set; }
        public string Autor { get; set; }
        public int Rok { get; set; }
        public string Typ { get; set; }
        public int PocetKusu { get; set; }
        public bool JeDostupna { get; set; }
    }
}
