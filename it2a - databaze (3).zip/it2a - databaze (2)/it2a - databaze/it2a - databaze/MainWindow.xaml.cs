﻿using System.Collections.ObjectModel;
using System.Diagnostics.Metrics;
using System.Linq; //todle je dulezity
using System.Security.Cryptography.X509Certificates; //?????????????????????
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace it2a___databaze
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ZakladniHry();
            DataContext = this;
            dgVideohry.ItemsSource = ListHer;
        }


        public int IdCounter = 3; //kompletne useless btw
        public int IdJiny;
        public string JmenoJiny;
        public string AutorJiny;
        public int RokJiny; //ja to musel zmenit na inty "brecici emoji x2" cas se zabit
        public string TypJiny;
        public int PocetKusuJiny;
        public bool JeDostupnaJiny;
        public List<int> roky = Enumerable.Range(1950, 80).ToList();

        public ObservableCollection<Hry> ListHer = new()
        {

        };
        public void ZakladniHry()
        {
            ListHer.Add(new Hry { Id = 1, Jmeno = "Peglin", Autor = "IndieArk", Rok = 2024, Typ = "Pachinko Roguelike", PocetKusu = 143, JeDostupna = true });
            ListHer.Add(new Hry { Id = 2, Jmeno = "Outcore", Autor = "Doctor Shinobi", Rok = 2022, Typ = "Desktop Adventure", PocetKusu = 67676767, JeDostupna = true });
            ListHer.Add(new Hry { Id = 3, Jmeno = "Ena: Dream BBQ", Autor = "Joel G", Rok = 2025, Typ = "Surrealism", PocetKusu = 52, JeDostupna = true });
        }
        public void Button_Click1(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(JmenoTextBox.Text))
            {
                MessageBox.Show("Zadejte platné jméno"); 
                JmenoTextBox.Clear();
            } else if (string.IsNullOrWhiteSpace(AutorTextBox.Text))
            {
                MessageBox.Show("Zadejte platného autora.");
                AutorTextBox.Clear();
            } else if (string.IsNullOrWhiteSpace(RokTextBox.Text) || int.TryParse(RokTextBox.Text, out var vysledek) == false || !roky.Contains(int.Parse(RokTextBox.Text)))
            {
                MessageBox.Show("Zadejte platný rok.");
                RokTextBox.Clear();
            } else if(string.IsNullOrWhiteSpace(PocetKusuTextBox.Text) || int.TryParse(PocetKusuTextBox.Text, out var vysledek2) == false || int.Parse(PocetKusuTextBox.Text) < 0)
            {
                MessageBox.Show("Zadejte platný počet kusů.");
                PocetKusuTextBox.Clear();
            } else
            {

                RokJiny = int.Parse(RokTextBox.Text);
                IdCounter += 1;
                IdJiny = IdCounter;
                JmenoJiny = JmenoTextBox.Text;
                AutorJiny = AutorTextBox.Text;
                TypJiny = TypTextBox.Text;
                PocetKusuJiny = int.Parse(PocetKusuTextBox.Text);
                if (JeDostupnaCheckBox.IsChecked ?? true) JeDostupnaJiny = true;
                else JeDostupnaJiny = false;
                ListHer.Add(new Hry { Id = IdCounter, Jmeno = JmenoJiny, Autor = AutorJiny, Rok = RokJiny, Typ = TypJiny, PocetKusu = PocetKusuJiny, JeDostupna = JeDostupnaJiny });
                dgVideohry.ItemsSource = ListHer;
            }
        }
        public void Button_Click2(object sender, RoutedEventArgs e)
        {
            if (dgVideohry.SelectedItem is Hry selected)
            {
                JmenoTextBox.Text = selected.Jmeno;
                AutorTextBox.Text = selected.Autor;
                RokTextBox.Text = selected.Rok.ToString();
                TypTextBox.Text = selected.Typ;
                PocetKusuTextBox.Text = selected.PocetKusu.ToString();
                if (selected.JeDostupna == true) JeDostupnaCheckBox.IsChecked = true;
                else JeDostupnaCheckBox.IsChecked = false;
            }
        }
        public void Button_Click3(object sender, RoutedEventArgs e)
        {
            if (dgVideohry.SelectedItem is Hry selected)
            {
                if (string.IsNullOrWhiteSpace(JmenoTextBox.Text))
                {
                    MessageBox.Show("Zadejte platné jméno");
                    JmenoTextBox.Clear();
                }
                else if (string.IsNullOrWhiteSpace(AutorTextBox.Text))
                {
                    MessageBox.Show("Zadejte platného autora.");
                    AutorTextBox.Clear();
                }
                else if (string.IsNullOrWhiteSpace(RokTextBox.Text) || int.TryParse(RokTextBox.Text, out var vysledek) == false || !roky.Contains(int.Parse(RokTextBox.Text)))
                {
                    MessageBox.Show("Zadejte platný rok.");
                    RokTextBox.Clear();
                }
                else if (string.IsNullOrWhiteSpace(PocetKusuTextBox.Text) || int.TryParse(PocetKusuTextBox.Text, out var vysledek2) == false || int.Parse(PocetKusuTextBox.Text) < 0)
                {
                    MessageBox.Show("Zadejte platný počet kusů.");
                    PocetKusuTextBox.Clear();
                }
                else
                {
                    selected.Jmeno = JmenoTextBox.Text;
                    selected.Autor = AutorTextBox.Text;
                    selected.Rok = int.Parse(RokTextBox.Text);
                    selected.Typ = TypTextBox.Text;
                    selected.PocetKusu = int.Parse(PocetKusuTextBox.Text);
                    if (JeDostupnaCheckBox.IsChecked == true) selected.JeDostupna = true;
                    else selected.JeDostupna = false;
                    dgVideohry.Items.Refresh();
                }
            }
        }
        public void Button_Click4(object sender, RoutedEventArgs e)
        {
            if (dgVideohry.SelectedItem != null) { 
            ListHer.Remove((Hry)dgVideohry.SelectedItem);
            }
        }
        public void Button_Click5(object sender, RoutedEventArgs e)
        {
            JmenoTextBox.Clear();
            AutorTextBox.Clear();
            RokTextBox.Clear();
            TypTextBox.Clear();
            PocetKusuTextBox.Clear();
            JeDostupnaCheckBox.IsChecked = false;
        }
    }
}